package com.Movie.movie.validator;

public class MovieNOtFoundException extends RuntimeException
{
    public MovieNOtFoundException(String msg)
    {
        super(msg);
    }
}
