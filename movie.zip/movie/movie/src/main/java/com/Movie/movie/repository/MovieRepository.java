package com.Movie.movie.repository;

import com.Movie.movie.model.Movie;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;

@Repository
public class MovieRepository
{
    List<Movie> movieList=new ArrayList<>();
    public Movie getmovie()
    {
        Movie movie=new Movie("satybhama","kajal","sudheep","dfghjk");
        return movie;
    }
    public Movie addmovie(Movie movie)
    {
        movieList.add(movie);
        return movie;
    }
    public List<Movie> getMovielist()
    {
        return movieList;
    }
}
