package com.Movie.movie.validator;

public class MovieException extends RuntimeException
{
     String errorcode;
//    public MovieException(String message)
//    {
//        super(message);
//    }
    public String getErrorcode() {
        return errorcode;
    }

    public void setErrorcode(String errorcode) {
        this.errorcode = errorcode;
    }
    public MovieException(String message,String errorcode)
    {
    super(message);
    this.errorcode=errorcode;
    }


}
