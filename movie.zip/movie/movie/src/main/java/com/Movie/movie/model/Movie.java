package com.Movie.movie.model;

public class Movie
{
    int id;
    String title;
    String actor;
    String director;
    String language;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public String getActor() {
        return actor;
    }

    public String getDirector() {
        return director;
    }

    public String getLanguage() {
        return language;
    }

    public Movie(String title, String actor, String director, String language)
    {
        this.title = title;
        this.actor = actor;
        this.director = director;
        this.language = language;
    }

    @Override
    public String toString() {
        return "Movie{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", actor='" + actor + '\'' +
                ", director='" + director + '\'' +
                ", language='" + language + '\'' +
                '}';
    }
}
