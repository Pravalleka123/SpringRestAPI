package com.Movie.movie.controller;
import com.Movie.movie.model.GetMovieResponse;
import com.Movie.movie.model.Movie;
import com.Movie.movie.service.MovieResponseService;
import com.Movie.movie.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/movie")

public class MovieController  {
    @Autowired
    MovieService movieService;
    @Autowired
    MovieResponseService movieResponseService;

    @GetMapping("/get")
//    public Movie movie(@RequestParam(name="movie", required=false) String name,
//                           Model model)
//    {
//
//        return movieService;
//    }
    public Movie movie()
    {
        return movieService.movie();
    }
    @PostMapping("/add")
    public Movie addMovie(@RequestBody Movie movie)
    {
        return  movieService.addmovie(movie);
    }
    @GetMapping("/all")
    public List<Movie> getMovielist()
    {
        return movieService.getMovielist();
    }
    @GetMapping("/getmovie")
    public GetMovieResponse getmovieslistbyactor(@RequestParam(name="actor")String name)
    {
        return movieResponseService.getallMoviesbyactor(name);

    }

    }


