package com.Movie.movie.validator;

import com.Movie.movie.model.Movie;
import org.springframework.stereotype.Component;

@Component
public class MovieValidator
{
    public void reqValidation(Movie movie)
    {
            if(movie.getTitle()==null)
            {
                throw new MovieException("Title should not be null","Error-101");
            }

            if(movie.getActor()==null)
            {
                throw new MovieException("actor should not be null","Error-201");
            }
            if(movie.getDirector()==null)
            {
                throw new MovieException("director should not be null","Error-301");
            }
            if(movie.getLanguage()==null)
            {
                throw new MovieException("language should not be null","Error-401");
            }
            if(movie.getId()!=0)
            {
                throw new MovieException("id should be null","Error-501");
            }
}
}
