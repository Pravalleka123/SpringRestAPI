package com.Movie.movie.service;

import com.Movie.movie.model.GetMovieResponse;
import com.Movie.movie.model.Movie;
import com.Movie.movie.model.MovieResponse;
import com.Movie.movie.repository.MovieRepository;
import com.Movie.movie.validator.MovieException;
import com.Movie.movie.validator.MovieNOtFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MovieResponseService {
    @Autowired
    MovieRepository movieRepository;

    public GetMovieResponse getallMoviesbyactor(String actor) {
        if (actor == null) {
            throw new MovieException("actor should not be null", "error 404");
        }
        List<Movie> movieList = movieRepository.getMovielist();
        List<MovieResponse> movieResponseList = movieList.stream()
                .filter(m -> m.getActor().equals(actor))
                .map(m1 -> new MovieResponse(m1.getTitle(), m1.getLanguage()))
                .collect(Collectors.toList());
        if (movieResponseList.size() == 0) {
            throw new MovieNOtFoundException("movie not found with that name");
        }
        GetMovieResponse getMovieResponse = new GetMovieResponse();
        getMovieResponse.setActor(actor);
        getMovieResponse.setMovieResponseList(movieResponseList);
        return getMovieResponse;

    }
}
